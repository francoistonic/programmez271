#!/usr/bin/env ruby

# Exemples de base pour le simulateur quantique Ruby
require_relative '../lib/quantum_simulator'

puts "================================"
puts "   Exemples Quantum Ruby"
puts "================================"

# Exemple 1: Qubit simple
puts "\n1. Manipulation de Qubit"
puts "-" * 25
qubit = Qubit.new(1, 0)
puts "État initial |0⟩: #{qubit.probabilities}"

h_gate = QuantumGate.new(QuantumGates::H_GATE)
qubit.state = h_gate.apply_to(qubit.state)
puts "Après Hadamard: #{qubit.probabilities}"

# Exemple 2: Circuit quantique
puts "\n2. Circuit Quantique"
puts "-" * 20
circuit = QuantumCircuit.new(2)
circuit.add_gate(QuantumGate.new(QuantumGates::H_GATE), [0])
circuit.add_gate(QuantumGate.cnot, [0, 1])

puts "Création d'un état de Bell..."
circuit.execute

# Mesures multiples
measurements = []
10.times do
  c = circuit.copy
  measurements << c.measure_all.join
end

puts "Résultats (10 mesures): #{measurements}"

# Exemple 3: Algorithme de Deutsch
puts "\n3. Algorithme de Deutsch"
puts "-" * 25

oracle = DeutschAlgorithm.constant_zero_oracle
result = DeutschAlgorithm.run(oracle)
puts "Fonction f(x)=0: #{result}"

oracle = DeutschAlgorithm.balanced_identity_oracle
result = DeutschAlgorithm.run(oracle)
puts "Fonction f(x)=x: #{result}"

# Exemple 4: Algorithme de Grover amélioré
puts "\n4. Algorithme de Grover"
puts "-" * 23

result = GroverAlgorithm.search(3, 5)
puts "Recherche de l'élément 5 parmi 8 éléments:"
puts "Élément trouvé: #{result[:found]}"
puts "Succès: #{result[:success]}"
puts "Probabilité: #{result[:success_probability].round(3)}"

# Exemple 5: VQE simple
puts "\n5. VQE (Variational Quantum Eigensolver)"
puts "-" * 38

# Créer un Hamiltonien simple (Pauli-Z)
hamiltonian = VQEAlgorithm.create_pauli_z_hamiltonian(2)
puts "Test VQE avec Hamiltonien Pauli-Z (2 qubits)..."

vqe = VQEAlgorithm.new(hamiltonian, 2)
result = vqe.optimize_ground_state(iterations: 30)
puts "Énergie de l'état fondamental: #{result[:ground_state_energy].round(4)}"

# Exemple 6: QAOA simple
puts "\n6. QAOA (Quantum Approximate Optimization)"
puts "-" * 42

# Créer un problème MaxCut simple
puts "Test QAOA avec problème MaxCut (3 qubits)..."
cost_hamiltonian = Matrix.identity(8)  # Hamiltonien simplifié

qaoa = QAOAAlgorithm.new(cost_hamiltonian, 3, layers: 2)
result = qaoa.solve_optimization_problem(iterations: 20)
puts "Coût optimal trouvé: #{result[:optimal_cost].round(4)}"
puts "Solution: #{result[:solution]}"

puts "\n✅ Tous les exemples terminés!"