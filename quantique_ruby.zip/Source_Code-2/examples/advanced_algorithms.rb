#!/usr/bin/env ruby

# Exemples avancés pour les algorithmes VQE et QAOA
require_relative '../lib/quantum_simulator'

puts "================================================"
puts "   Algorithmes Quantiques Avancés - Ruby"
puts "================================================"

# Exemple 1: VQE avec différents Hamiltoniens
puts "\n1. VQE - Variational Quantum Eigensolver"
puts "=" * 40

puts "\n1.1 Hamiltonien Pauli-Z (problème simple)"
puts "-" * 35

hamiltonian_z = VQEAlgorithm.create_pauli_z_hamiltonian(2)
puts "Matrice du Hamiltonien Pauli-Z:"
hamiltonian_z.to_a.each { |row| puts row.map { |x| x.round(2) }.inspect }

vqe_z = VQEAlgorithm.new(hamiltonian_z, 2)
result_z = vqe_z.optimize_ground_state(iterations: 50)

puts "\nRésultats VQE (Pauli-Z):"
puts "Énergie fondamentale: #{result_z[:ground_state_energy].round(6)}"
puts "Paramètres optimaux: #{result_z[:optimal_parameters].map { |p| p.round(3) }}"

# Vérification classique
eigenvalues = hamiltonian_z.eigenvalues.sort
puts "Énergie exacte (diagonalisation): #{eigenvalues.first.round(6)}"
puts "Erreur VQE: #{(result_z[:ground_state_energy] - eigenvalues.first).abs.round(6)}"

puts "\n1.2 Modèle d'Ising (plus complexe)"
puts "-" * 30

hamiltonian_ising = VQEAlgorithm.create_ising_hamiltonian(2, coupling_strength: 0.5)
puts "Matrice du Hamiltonien d'Ising:"
hamiltonian_ising.to_a.each { |row| puts row.map { |x| x.round(2) }.inspect }

vqe_ising = VQEAlgorithm.new(hamiltonian_ising, 2)
result_ising = vqe_ising.optimize_ground_state(iterations: 50)

puts "\nRésultats VQE (Ising):"
puts "Énergie fondamentale: #{result_ising[:ground_state_energy].round(6)}"
puts "Paramètres optimaux: #{result_ising[:optimal_parameters].map { |p| p.round(3) }}"

# Vérification classique
eigenvalues_ising = hamiltonian_ising.eigenvalues.sort
puts "Énergie exacte (diagonalisation): #{eigenvalues_ising.first.round(6)}"
puts "Erreur VQE: #{(result_ising[:ground_state_energy] - eigenvalues_ising.first).abs.round(6)}"

# Exemple 2: QAOA avec problème MaxCut
puts "\n\n2. QAOA - Quantum Approximate Optimization Algorithm"
puts "=" * 52

puts "\n2.1 Problème MaxCut simple (4 sommets)"
puts "-" * 33

# Définir le graphe: carré avec diagonale
edges = [[0, 1], [1, 2], [2, 3], [3, 0], [0, 2]]
adjacency_matrix = QAOAAlgorithm.create_maxcut_problem(4, edges)

puts "Arêtes du graphe: #{edges}"
puts "Matrice d'adjacence:"
adjacency_matrix.each { |row| puts row.inspect }

# Solution classique (force brute)
classical_result = QAOAAlgorithm.classical_maxcut_solution(adjacency_matrix)
puts "\nSolution classique optimale:"
puts "Valeur de coupe maximale: #{classical_result[:cut_value]}"
puts "Partition optimale: #{classical_result[:partition]}"

# Solution QAOA
puts "\nSolution QAOA:"
cost_hamiltonian = Matrix.identity(16)  # Hamiltonien simplifié pour la démo

qaoa = QAOAAlgorithm.new(cost_hamiltonian, 4, layers: 2)
qaoa_result = qaoa.solve_optimization_problem(iterations: 80)

qaoa_cut_value = qaoa.calculate_maxcut_cost(qaoa_result[:solution])
approximation_ratio = qaoa_cut_value.to_f / classical_result[:cut_value]

puts "Meilleur coût QAOA: #{qaoa_result[:optimal_cost].round(4)}"
puts "Solution QAOA: #{qaoa_result[:solution]}"
puts "Valeur de coupe QAOA: #{qaoa_cut_value}"
puts "Ratio d'approximation: #{approximation_ratio.round(3)}"

puts "\n2.2 Analyse de la profondeur des couches"
puts "-" * 35

[1, 2, 3, 4].each do |layers|
  qaoa_test = QAOAAlgorithm.new(cost_hamiltonian, 4, layers: layers)
  test_result = qaoa_test.solve_optimization_problem(iterations: 40)
  test_cut = qaoa_test.calculate_maxcut_cost(test_result[:solution])
  test_ratio = test_cut.to_f / classical_result[:cut_value]
  
  puts "#{layers} couches: coupe = #{test_cut}/#{classical_result[:cut_value]}, ratio = #{test_ratio.round(3)}"
end

# Exemple 3: Comparaison des algorithmes
puts "\n\n3. Analyse Comparative des Algorithmes"
puts "=" * 38

puts "\n3.1 Performance VQE selon la taille du système"
puts "-" * 40

[2, 3].each do |n_qubits|
  hamiltonian = VQEAlgorithm.create_ising_hamiltonian(n_qubits)
  vqe = VQEAlgorithm.new(hamiltonian, n_qubits)
  
  start_time = Time.now
  result = vqe.optimize_ground_state(iterations: 30)
  elapsed = Time.now - start_time
  
  # Calcul exact pour comparaison
  exact_energy = hamiltonian.eigenvalues.min
  error = (result[:ground_state_energy] - exact_energy).abs
  
  puts "#{n_qubits} qubits: énergie = #{result[:ground_state_energy].round(4)}, " \
       "erreur = #{error.round(6)}, temps = #{elapsed.round(2)}s"
end

puts "\n3.2 Convergence VQE détaillée"
puts "-" * 28

hamiltonian_conv = VQEAlgorithm.create_ising_hamiltonian(2)
vqe_conv = VQEAlgorithm.new(hamiltonian_conv, 2)
convergence_data = vqe_conv.analyze_convergence(iterations: 100, tolerance: 1e-6)

puts "Historique d'énergie (10 dernières):"
puts convergence_data[:energy_history].last(10).map { |e| e.round(6) }.inspect
puts "Convergence atteinte à l'itération: #{convergence_data[:converged_at] || 'Non convergé'}"
puts "Énergie finale: #{convergence_data[:final_energy].round(6)}"

# Exemple 4: Applications pratiques
puts "\n\n4. Applications Pratiques"
puts "=" * 25

puts "\n4.1 Simulation moléculaire simple (VQE)"
puts "-" * 35

puts "Simulation d'une molécule H2 simplifiée:"
# Hamiltonien simplifié pour H2
h2_hamiltonian = Matrix[
  [-1.0, 0, 0, 0],
  [0, -0.5, -0.5, 0],
  [0, -0.5, -0.5, 0],
  [0, 0, 0, 0.5]
]

vqe_h2 = VQEAlgorithm.new(h2_hamiltonian, 2)
h2_result = vqe_h2.optimize_ground_state(iterations: 60)

puts "Énergie de liaison H2: #{h2_result[:ground_state_energy].round(6)} unités atomiques"
puts "Configuration électronique optimale trouvée"

puts "\n4.2 Optimisation de réseau (QAOA)"
puts "-" * 30

puts "Optimisation d'un réseau de communication (5 nœuds):"
network_edges = [[0, 1], [1, 2], [2, 3], [3, 4], [4, 0], [0, 3], [1, 4]]
network_matrix = QAOAAlgorithm.create_maxcut_problem(5, network_edges)

classical_network = QAOAAlgorithm.classical_maxcut_solution(network_matrix)
puts "Solution optimale classique: #{classical_network[:cut_value]} connexions coupées"

network_hamiltonian = Matrix.identity(32)
qaoa_network = QAOAAlgorithm.new(network_hamiltonian, 5, layers: 3)
network_result = qaoa_network.solve_optimization_problem(iterations: 60)

network_cut = qaoa_network.calculate_maxcut_cost(network_result[:solution])
puts "Solution QAOA: #{network_cut} connexions coupées"
puts "Efficacité: #{(network_cut.to_f / classical_network[:cut_value] * 100).round(1)}%"

puts "\n" + "=" * 50
puts "🎯 Analyse terminée - Tous les algorithmes testés!"
puts "=" * 50

puts "\nRésumé des performances:"
puts "- VQE: Excellent pour trouver les états fondamentaux"
puts "- QAOA: Efficace pour l'optimisation combinatoire"
puts "- Les deux montrent des avantages quantiques prometteurs"
puts "\nPour des problèmes plus complexes, utilisez des "
puts "ordinateurs quantiques réels via les APIs cloud!"