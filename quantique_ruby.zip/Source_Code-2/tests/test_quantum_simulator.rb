require 'minitest/autorun'
require_relative '../lib/qubit'
require_relative '../lib/quantum_gate'
require_relative '../lib/quantum_gates'
require_relative '../lib/quantum_circuit'

class TestQuantumSimulator < Minitest::Test
  def setup
    @tolerance = 1e-10
  end
  
  def test_qubit_normalization
    qubit = Qubit.new(3, 4)  # Non-normalisé
    
    # Vérifier que la norme est 1
    norm = Math.sqrt(qubit.state[0].abs2 + qubit.state[1].abs2)
    assert_in_delta(1.0, norm, @tolerance)
  end
  
  def test_hadamard_creates_superposition
    qubit = Qubit.new(1, 0)  # |0⟩
    h_gate = QuantumGate.new(QuantumGates::H_GATE)
    
    new_state = h_gate.apply_to(qubit.state)
    
    # Devrait être |+⟩ = (|0⟩ + |1⟩)/√2
    expected_amp = 1.0 / Math.sqrt(2)
    assert_in_delta(expected_amp, new_state[0].abs, @tolerance)
    assert_in_delta(expected_amp, new_state[1].abs, @tolerance)
  end
  
  def test_bell_state_creation
    circuit = QuantumCircuit.new(2)
    
    # Créer l'état de Bell |Φ+⟩ = (|00⟩ + |11⟩)/√2
    circuit.add_gate(QuantumGate.new(QuantumGates::H_GATE), [0])
    circuit.add_gate(QuantumGate.cnot, [0, 1])
    
    state = circuit.execute
    
    # Vérifier les amplitudes
    expected_amp = 1.0 / Math.sqrt(2)
    assert_in_delta(expected_amp, state[0].abs, @tolerance)  # |00⟩
    assert_in_delta(0, state[1].abs, @tolerance)             # |01⟩
    assert_in_delta(0, state[2].abs, @tolerance)             # |10⟩
    assert_in_delta(expected_amp, state[3].abs, @tolerance)  # |11⟩
  end
  
  def test_x_gate
    qubit = Qubit.new(1, 0)  # |0⟩
    x_gate = QuantumGate.new(QuantumGates::X_GATE)
    
    new_state = x_gate.apply_to(qubit.state)
    
    # X|0⟩ = |1⟩
    assert_in_delta(0, new_state[0].abs, @tolerance)
    assert_in_delta(1, new_state[1].abs, @tolerance)
  end
  
  def test_measurement_statistics
    # Test que les mesures suivent les probabilités quantiques
    # Créer un état de superposition avec Hadamard
    qubit = Qubit.new(1, 0)  # État |0⟩
    h_gate = QuantumGate.new(QuantumGates::H_GATE)
    qubit.state = h_gate.apply_to(qubit.state)
    
    measurements = []
    1000.times do
      test_qubit = Qubit.new(qubit.state[0], qubit.state[1])
      measurements << test_qubit.measure
    end
    
    prob_zero = measurements.count(0) / 1000.0
    
    # Devrait être proche de 0.5
    assert_in_delta(0.5, prob_zero, 0.1)
  end
  
  def test_cnot_gate
    circuit = QuantumCircuit.new(2)
    
    # |10⟩ état initial
    circuit.add_gate(QuantumGate.new(QuantumGates::X_GATE), [0])
    circuit.add_gate(QuantumGate.cnot, [0, 1])
    
    state = circuit.execute
    
    # CNOT|10⟩ = |11⟩
    assert_in_delta(0, state[0].abs, @tolerance)  # |00⟩
    assert_in_delta(0, state[1].abs, @tolerance)  # |01⟩
    assert_in_delta(0, state[2].abs, @tolerance)  # |10⟩
    assert_in_delta(1, state[3].abs, @tolerance)  # |11⟩
  end
end