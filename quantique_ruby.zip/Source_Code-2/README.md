# Quantum Ruby Simulator

A comprehensive quantum computing simulator implemented in Ruby, demonstrating fundamental quantum mechanics principles and quantum algorithms.

## Overview

This project implements a fully functional quantum computer simulator in Ruby, featuring:
- Quantum state representation and manipulation
- Comprehensive quantum gate library
- Multi-qubit quantum circuits
- Implementation of famous quantum algorithms
- Educational examples and comprehensive tests

## Features

### Core Components
- **Qubit**: Quantum bit representation with complex amplitudes
- **Quantum Gates**: Complete set of single and multi-qubit gates
- **Quantum Circuits**: Build and execute complex quantum circuits
- **Measurement**: Probabilistic quantum measurement simulation

### Quantum Gates Implemented
- **Pauli Gates**: X, Y, Z (fundamental operations)
- **Hadamard Gate**: Creates superposition states
- **Phase Gates**: S, T gates for phase manipulation
- **Rotation Gates**: RX, RY, RZ for arbitrary rotations
- **Multi-qubit Gates**: CNOT, Toffoli, SWAP
- **Controlled Gates**: Controlled phase operations

### Quantum Algorithms
- **Deutsch Algorithm**: Determines if a function is constant or balanced
- **Grover's Search**: Quantum search with quadratic speedup (O(√N))
- **VQE (Variational Quantum Eigensolver)**: Hybrid algorithm for finding ground states
- **QAOA (Quantum Approximate Optimization)**: Solves combinatorial optimization problems
- **Quantum Teleportation**: Demonstrates quantum information transfer
- **Bell State Creation**: Quantum entanglement demonstration

### Advanced Features
- **QASM Export**: Export circuits to OpenQASM format
- **Performance Analysis**: Benchmarking and scalability tests
- **Statistical Validation**: Comprehensive test suite
- **Cloud Integration**: Framework for quantum cloud services

## Installation

### Prerequisites
- Ruby 2.7 or higher
- Bundler gem

## Quick Start

### Basic Qubit Operations
```ruby
require_relative 'lib/quantum_simulator'

# Create a qubit in |0⟩ state
qubit = Qubit.new(1, 0)
puts "Initial probabilities: #{qubit.probabilities}"

# Apply Hadamard gate for superposition
h_gate = QuantumGate.new(QuantumGates::H_GATE)
qubit.state = h_gate.apply_to(qubit.state)
puts "After Hadamard: #{qubit.probabilities}"

# Measure the qubit
result = qubit.measure
puts "Measurement result: #{result}"
```

### Creating Quantum Circuits
```ruby
# Create a 2-qubit Bell state
circuit = QuantumCircuit.new(2)
circuit.add_gate(QuantumGate.new(QuantumGates::H_GATE), [0])
circuit.add_gate(QuantumGate.cnot, [0, 1])

# Execute and measure
circuit.execute
results = circuit.measure_all
puts "Bell state measurement: #{results}"
```

### Running Quantum Algorithms
```ruby
# Deutsch Algorithm
oracle = DeutschAlgorithm.constant_zero_oracle
result = DeutschAlgorithm.run(oracle)
puts "Function type: #{result}"

# Grover's Search
marked_item = 3
result = GroverAlgorithm.search(2, marked_item)
puts "Found item: #{result[:found]}"

# VQE Algorithm
hamiltonian = VQEAlgorithm.create_pauli_z_hamiltonian(2)
vqe = VQEAlgorithm.new(hamiltonian, 2)
result = vqe.optimize_ground_state(iterations: 50)
puts "Ground state energy: #{result[:ground_state_energy]}"

# QAOA Algorithm
cost_hamiltonian = Matrix.identity(8)
qaoa = QAOAAlgorithm.new(cost_hamiltonian, 3, layers: 2)
result = qaoa.solve_optimization_problem(iterations: 100)
puts "Optimal cost: #{result[:optimal_cost]}"
```

## Project Structure

```
lib/
├── qubit.rb                    # Quantum bit implementation
├── quantum_gate.rb             # Quantum gate class
├── quantum_gates.rb            # Gate definitions
├── quantum_circuit.rb          # Circuit builder and executor
├── quantum_simulator.rb        # Main simulator class
└── algorithms/
    ├── deutsch_algorithm.rb    # Deutsch's algorithm
    ├── grover_algorithm.rb     # Grover's search (enhanced)
    ├── vqe_algorithm.rb        # Variational Quantum Eigensolver
    ├── qaoa_algorithm.rb       # Quantum Approximate Optimization
    └── quantum_teleportation.rb # Teleportation protocol

examples/
├── basic_examples.rb           # Basic usage examples
└── advanced_algorithms.rb     # VQE and QAOA examples

tests/
└── test_quantum_simulator.rb   # Comprehensive test suite

Gemfile                         # Ruby dependencies
LICENSE                         # MIT license
README.md                       # This file
```

## Running Examples

### All Examples
```bash
ruby lib/quantum_simulator.rb
```

### Specific Examples
```bash
# Basic quantum operations
ruby examples/basic_examples.rb

# Advanced algorithms (VQE, QAOA)
ruby examples/advanced_algorithms.rb
```

### Individual Algorithms
```ruby
# In Ruby console
require_relative 'lib/quantum_simulator'

# Run Grover's algorithm demo
GroverAlgorithm.demonstrate

# Run VQE demo
VQEAlgorithm.demonstrate

# Run QAOA demo
QAOAAlgorithm.demonstrate

# Run quantum teleportation demo
QuantumTeleportation.demonstrate
```

## Running Tests

```bash
# Run all tests
ruby tests/test_quantum_simulator.rb

# Or using minitest
bundle exec ruby -Ilib:test tests/test_quantum_simulator.rb
```

## Performance Considerations

This simulator can efficiently handle:
- **1-8 qubits**: Excellent performance
- **9-12 qubits**: Good performance on modern machines
- **13+ qubits**: Memory constraints become significant

Memory usage grows exponentially: 2^n complex numbers for n qubits.

## Educational Use

This simulator is designed for:
- Learning quantum computing fundamentals
- Experimenting with quantum algorithms
- Prototyping quantum circuits
- Understanding quantum mechanics principles

## API Documentation

### Qubit Class
```ruby
# Create qubit with amplitudes α|0⟩ + β|1⟩
qubit = Qubit.new(alpha, beta)

# Measure qubit (returns 0 or 1)
result = qubit.measure

# Get measurement probabilities
probs = qubit.probabilities  # [P(0), P(1)]
```

### QuantumCircuit Class
```ruby
# Create n-qubit circuit
circuit = QuantumCircuit.new(n)

# Add gates
circuit.add_gate(gate, target_qubits)

# Execute circuit
final_state = circuit.execute

# Measure all qubits
results = circuit.measure_all
```

### Quantum Gates
```ruby
# Single-qubit gates
h_gate = QuantumGate.new(QuantumGates::H_GATE)
x_gate = QuantumGate.new(QuantumGates::X_GATE)

# Multi-qubit gates
cnot = QuantumGate.cnot
toffoli = QuantumGate.toffoli

# Parameterized gates
rx = QuantumGate.new(QuantumGates.rx_gate(Math::PI/4))
```


### Development Guidelines
- Follow Ruby style conventions
- Add comprehensive tests for new features
- Document complex algorithms
- Maintain backward compatibility
- Update examples for new functionality

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- Inspired by IBM Qiskit and other quantum computing frameworks
- Quantum algorithms based on standard implementations
- Built for educational purposes and Ruby community

## References

- Nielsen, M. A., & Chuang, I. L. (2010). Quantum Computation and Quantum Information
- Yanofsky, N. S., & Mannucci, M. A. (2008). Quantum Computing for Computer Scientists
- IBM Qiskit Documentation: https://qiskit.org/
- Microsoft Q# Documentation: https://docs.microsoft.com/quantum/



---

*"The best way to understand quantum computing is to build a quantum computer simulator."*
