require 'matrix'

class QuantumGate
  attr_reader :matrix, :num_qubits
  
  def initialize(matrix, num_qubits = 1)
    @matrix = matrix
    @num_qubits = num_qubits
  end
  
  def apply_to(state_vector)
    @matrix * state_vector
  end
  
  # Produit tensoriel pour combiner des portes
  def tensor(other)
    new_matrix = Matrix.build(@matrix.row_count * other.matrix.row_count,
                              @matrix.column_count * other.matrix.column_count) do |i, j|
      @matrix[i / other.matrix.row_count, j / other.matrix.column_count] *
      other.matrix[i % other.matrix.row_count, j % other.matrix.column_count]
    end
    QuantumGate.new(new_matrix, @num_qubits + other.num_qubits)
  end
  
  # Porte CNOT (Controlled-NOT)
  def self.cnot
    matrix = Matrix[
      [1, 0, 0, 0],
      [0, 1, 0, 0],
      [0, 0, 0, 1],
      [0, 0, 1, 0]
    ]
    new(matrix, 2)
  end
  
  # Porte de Toffoli (CCNOT)
  def self.toffoli
    matrix = Matrix.identity(8)
    matrix[6, 6] = 0
    matrix[6, 7] = 1
    matrix[7, 6] = 1
    matrix[7, 7] = 0
    new(matrix, 3)
  end
  
  # SWAP gate
  def self.swap
    matrix = Matrix[
      [1, 0, 0, 0],
      [0, 0, 1, 0],
      [0, 1, 0, 0],
      [0, 0, 0, 1]
    ]
    new(matrix, 2)
  end
  
  # Controlled phase gate
  def self.controlled_phase(angle)
    matrix = Matrix[
      [1, 0, 0, 0],
      [0, 1, 0, 0],
      [0, 0, 1, 0],
      [0, 0, 0, Complex(Math.cos(angle), Math.sin(angle))]
    ]
    new(matrix, 2)
  end
  
  # Dagger (adjoint) of a gate
  def dagger
    QuantumGate.new(@matrix.conjugate.transpose, @num_qubits)
  end
end