#!/usr/bin/env ruby

# Main entry point for the Quantum Ruby Simulator
require_relative 'qubit'
require_relative 'quantum_gate'
require_relative 'quantum_gates'
require_relative 'quantum_circuit'

# Load all algorithms
Dir[File.join(__dir__, 'algorithms', '*.rb')].each { |file| require file }

class QuantumSimulator
  def self.run_examples
    puts "====================================="
    puts "  Quantum Ruby Simulator Examples"
    puts "====================================="
    puts
    
    # Example 1: Basic Qubit Operations
    puts "1. Basic Qubit Operations"
    puts "-" * 30
    demonstrate_qubit_basics
    puts
    
    # Example 2: Quantum Gates
    puts "2. Quantum Gates"
    puts "-" * 30
    demonstrate_quantum_gates
    puts
    
    # Example 3: Bell State
    puts "3. Bell State Creation"
    puts "-" * 30
    demonstrate_bell_state
    puts
    
    # Example 4: Deutsch Algorithm
    puts "4. Deutsch Algorithm"
    puts "-" * 30
    demonstrate_deutsch_algorithm
    puts
    
    # Example 5: Quantum Teleportation
    puts "5. Quantum Teleportation"
    puts "-" * 30
    QuantumTeleportation.demonstrate
    puts
    
    # Example 6: Grover's Algorithm
    puts "6. Grover's Search Algorithm"
    puts "-" * 30
    GroverAlgorithm.demonstrate
    puts
    
    # Example 7: VQE Algorithm
    puts "7. Variational Quantum Eigensolver (VQE)"
    puts "-" * 40
    VQEAlgorithm.demonstrate
    puts
    
    # Example 8: QAOA Algorithm
    puts "8. Quantum Approximate Optimization Algorithm (QAOA)"
    puts "-" * 50
    QAOAAlgorithm.demonstrate
    puts
  end
  
  private
  
  def self.demonstrate_qubit_basics
    # Create a qubit in |0⟩ state
    qubit = Qubit.new(1, 0)
    puts "Initial state |0⟩:"
    puts "  Probabilities: |0⟩=#{qubit.probabilities[0].round(3)}, |1⟩=#{qubit.probabilities[1].round(3)}"
    
    # Apply Hadamard gate
    h_gate = QuantumGate.new(QuantumGates::H_GATE)
    qubit.state = h_gate.apply_to(qubit.state)
    puts "\nAfter Hadamard gate:"
    puts "  Probabilities: |0⟩=#{qubit.probabilities[0].round(3)}, |1⟩=#{qubit.probabilities[1].round(3)}"
    
    # Measure the qubit
    result = qubit.measure
    puts "\nMeasurement result: #{result}"
    puts "  After measurement: |0⟩=#{qubit.probabilities[0].round(3)}, |1⟩=#{qubit.probabilities[1].round(3)}"
  end
  
  def self.demonstrate_quantum_gates
    qubit = Qubit.new(1, 0)
    
    # X Gate (NOT)
    x_gate = QuantumGate.new(QuantumGates::X_GATE)
    qubit.state = x_gate.apply_to(qubit.state)
    puts "After X gate: |0⟩=#{qubit.probabilities[0].round(3)}, |1⟩=#{qubit.probabilities[1].round(3)}"
    
    # Y Gate
    qubit = Qubit.new(1, 0)
    y_gate = QuantumGate.new(QuantumGates::Y_GATE)
    qubit.state = y_gate.apply_to(qubit.state)
    puts "After Y gate: |0⟩=#{qubit.probabilities[0].round(3)}, |1⟩=#{qubit.probabilities[1].round(3)}"
    
    # Z Gate
    qubit = Qubit.new(1, 1)  # Start in superposition
    z_gate = QuantumGate.new(QuantumGates::Z_GATE)
    qubit.state = z_gate.apply_to(qubit.state)
    puts "After Z gate: |0⟩=#{qubit.probabilities[0].round(3)}, |1⟩=#{qubit.probabilities[1].round(3)}"
  end
  
  def self.demonstrate_bell_state
    circuit = QuantumCircuit.new(2)
    
    # Create Bell state |Φ+⟩ = (|00⟩ + |11⟩)/√2
    circuit.add_gate(QuantumGate.new(QuantumGates::H_GATE), [0])
    circuit.add_gate(QuantumGate.cnot, [0, 1])
    
    puts "Creating Bell state |Φ+⟩ = (|00⟩ + |11⟩)/√2"
    circuit.execute
    
    # Measure multiple times to show correlation
    measurements = []
    100.times do
      c = circuit.copy
      measurements << c.measure_all.join
    end
    
    counts = measurements.group_by(&:itself).transform_values(&:count)
    puts "\nMeasurement results (100 shots):"
    counts.each do |state, count|
      puts "  |#{state}⟩: #{count} times (#{count}%)"
    end
    puts "\nNote: Only |00⟩ and |11⟩ appear, showing entanglement!"
  end
  
  def self.demonstrate_deutsch_algorithm
    # Test all four possible functions
    oracles = {
      "f(x) = 0" => DeutschAlgorithm.constant_zero_oracle,
      "f(x) = 1" => DeutschAlgorithm.constant_one_oracle,
      "f(x) = x" => DeutschAlgorithm.balanced_identity_oracle,
      "f(x) = NOT x" => DeutschAlgorithm.balanced_not_oracle
    }
    
    oracles.each do |name, oracle|
      result = DeutschAlgorithm.run(oracle)
      puts "Function #{name} is: #{result}"
    end
  end
end

# Run examples if this file is executed directly
if __FILE__ == $0
  QuantumSimulator.run_examples
end