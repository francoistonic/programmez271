require_relative '../quantum_circuit'
require_relative '../quantum_gate'
require_relative '../quantum_gates'

class DeutschAlgorithm
  def self.run(oracle)
    circuit = QuantumCircuit.new(2)
    
    # Préparation : H sur le premier qubit, X puis H sur le second
    circuit.add_gate(QuantumGate.new(QuantumGates::H_GATE), [0])
    circuit.add_gate(QuantumGate.new(QuantumGates::X_GATE), [1])
    circuit.add_gate(QuantumGate.new(QuantumGates::H_GATE), [1])
    
    # Application de l'oracle
    circuit.add_gate(oracle, [0, 1])
    
    # H final sur le premier qubit
    circuit.add_gate(QuantumGate.new(QuantumGates::H_GATE), [0])
    
    # Mesure
    circuit.execute
    result = circuit.measure_all
    
    # Si le premier qubit est 1, la fonction est balancée
    # Si 0, la fonction est constante
    result[0] == 1 ? "balanced" : "constant"
  end
  
  # Oracle implementations
  def self.constant_zero_oracle
    # f(x) = 0 for all x
    QuantumGate.new(Matrix.identity(4), 2)
  end
  
  def self.constant_one_oracle
    # f(x) = 1 for all x
    matrix = Matrix[
      [1, 0, 0, 0],
      [0, 0, 0, 1],
      [0, 0, 1, 0],
      [0, 1, 0, 0]
    ]
    QuantumGate.new(matrix, 2)
  end
  
  def self.balanced_identity_oracle
    # f(x) = x
    QuantumGate.cnot
  end
  
  def self.balanced_not_oracle
    # f(x) = NOT x
    matrix = Matrix[
      [0, 1, 0, 0],
      [1, 0, 0, 0],
      [0, 0, 1, 0],
      [0, 0, 0, 1]
    ]
    x_gate = QuantumGate.new(QuantumGates::X_GATE)
    i_gate = QuantumGate.new(QuantumGates::I_GATE)
    cnot = QuantumGate.cnot
    
    # Apply X to first qubit, then CNOT
    QuantumGate.new(matrix * cnot.matrix, 2)
  end
end