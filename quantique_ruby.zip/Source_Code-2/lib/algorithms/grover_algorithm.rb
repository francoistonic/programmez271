require_relative '../quantum_circuit'
require_relative '../quantum_gate'
require_relative '../quantum_gates'

class GroverAlgorithm
  def self.search(n_qubits, marked_item)
    circuit = QuantumCircuit.new(n_qubits)
    n_items = 2**n_qubits
    iterations = (Math::PI * Math.sqrt(n_items) / 4).to_i
    
    puts "Recherche de l'élément #{marked_item} parmi #{n_items} éléments"
    puts "Nombre d'itérations optimales : #{iterations}"
    
    # Superposition initiale
    n_qubits.times do |i|
      circuit.add_gate(QuantumGate.new(QuantumGates::H_GATE), [i])
    end
    
    # Itérations de Grover
    iterations.times do |iter|
      apply_oracle_improved(circuit, marked_item, n_qubits)
      apply_diffusion_operator(circuit, n_qubits)
    end
    
    circuit.execute
    result = circuit.measure_all
    found_item = result.join.to_i(2)
    
    {
      found: found_item,
      success: found_item == marked_item,
      iterations: iterations,
      success_probability: calculate_success_probability(iterations, n_items)
    }
  end
  
  private
  
  def self.apply_oracle_improved(circuit, marked, n_qubits)
    # Oracle multi-contrôlé robuste avec inversion de phase
    marked_binary = marked.to_s(2).rjust(n_qubits, '0').chars.map(&:to_i)
    
    # Préparer l'état cible avec des portes X conditionnelles
    marked_binary.each_with_index do |bit, i|
      if bit == 0
        circuit.add_gate(QuantumGate.new(QuantumGates::X_GATE), [i])
      end
    end
    
    # Porte Z multi-contrôlée (inversion de phase)
    apply_multi_controlled_z(circuit, n_qubits)
    
    # Défaire les portes X conditionnelles
    marked_binary.each_with_index do |bit, i|
      if bit == 0
        circuit.add_gate(QuantumGate.new(QuantumGates::X_GATE), [i])
      end
    end
  end
  
  def self.apply_multi_controlled_z(circuit, n_qubits)
    if n_qubits == 1
      circuit.add_gate(QuantumGate.new(QuantumGates::Z_GATE), [0])
    elsif n_qubits == 2
      # CZ gate pour 2 qubits
      circuit.add_gate(QuantumGate.new(QuantumGates::H_GATE), [1])
      circuit.add_gate(QuantumGate.cnot, [0, 1])
      circuit.add_gate(QuantumGate.new(QuantumGates::H_GATE), [1])
    else
      # Approximation pour plus de qubits (nécessiterait des qubits auxiliaires en réalité)
      circuit.add_gate(QuantumGate.new(QuantumGates::Z_GATE), [n_qubits - 1])
    end
  end
  
  def self.apply_diffusion_operator(circuit, n_qubits)
    # Opérateur de diffusion de Grover : 2|s⟩⟨s| - I
    # où |s⟩ est l'état de superposition uniforme
    
    # H† sur tous les qubits (retour à la base computationnelle)
    n_qubits.times do |i|
      circuit.add_gate(QuantumGate.new(QuantumGates::H_GATE), [i])
    end
    
    # Inversion autour de |0...0⟩
    # X sur tous les qubits
    n_qubits.times do |i|
      circuit.add_gate(QuantumGate.new(QuantumGates::X_GATE), [i])
    end
    
    # Z multi-contrôlée
    apply_multi_controlled_z(circuit, n_qubits)
    
    # X sur tous les qubits (défaire)
    n_qubits.times do |i|
      circuit.add_gate(QuantumGate.new(QuantumGates::X_GATE), [i])
    end
    
    # H sur tous les qubits (retour à la superposition)
    n_qubits.times do |i|
      circuit.add_gate(QuantumGate.new(QuantumGates::H_GATE), [i])
    end
  end
  
  def self.calculate_success_probability(iterations, n_items)
    theta = Math.asin(1.0 / Math.sqrt(n_items))
    sin_value = Math.sin((2 * iterations + 1) * theta)
    sin_value * sin_value
  end
  
  def self.demonstrate_grover_variants
    puts "=== Démonstration des Variantes de Grover ==="
    
    # Test standard
    result = search(3, 5)
    puts "Recherche standard : Élément #{result[:found]}, Succès: #{result[:success]}"
    puts "Probabilité théorique : #{result[:success_probability].round(3)}"
    
    # Test avec probabilité de succès
    puts "\nAnalyse de performance :"
    [2, 3, 4].each do |n|
      items = 2**n
      optimal_iter = (Math::PI * Math.sqrt(items) / 4).to_i
      prob = calculate_success_probability(optimal_iter, items)
      puts "#{n} qubits (#{items} éléments) : #{optimal_iter} itérations, P(succès) = #{prob.round(3)}"
    end
  end
  
  def self.demonstrate
    puts "=== Grover's Algorithm Demo ==="
    
    # Recherche dans une base de 4 éléments (2 qubits)
    n_qubits = 2
    marked = 3  # Chercher l'élément 3 (11 en binaire)
    
    result = search(n_qubits, marked)
    
    puts "\nResults:"
    puts "Found item: #{result[:found]}"
    puts "Success: #{result[:success]}"
    puts "Used #{result[:iterations]} iterations"
    puts "Success probability: #{result[:success_probability].round(3)}" if result[:success_probability]
    
    # Test avec plus de qubits
    puts "\n--- Larger search space ---"
    n_qubits = 3
    marked = 5
    
    result = search(n_qubits, marked)
    
    puts "\nResults:"
    puts "Found item: #{result[:found]}"
    puts "Success: #{result[:success]}"
    puts "Used #{result[:iterations]} iterations"
    puts "Success probability: #{result[:success_probability].round(3)}" if result[:success_probability]
    
    # Demonstrate variants
    puts "\n"
    demonstrate_grover_variants
  end
end