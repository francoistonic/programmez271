require_relative '../quantum_circuit'
require_relative '../quantum_gate'
require_relative '../quantum_gates'
require 'matrix'

class VQEAlgorithm
  attr_reader :hamiltonian, :n_qubits, :parameters
  
  def initialize(hamiltonian, n_qubits)
    @hamiltonian = hamiltonian
    @n_qubits = n_qubits
    @parameters = Array.new(2 * n_qubits) { rand * 2 * Math::PI }
    @best_energy = Float::INFINITY
    @best_params = nil
  end
  
  def optimize_ground_state(iterations: 100)
    best_energy = Float::INFINITY
    best_params = @parameters.dup
    
    puts "=== VQE Optimization Started ==="
    puts "Initial parameters: #{@parameters.map { |p| p.round(3) }}"
    
    iterations.times do |iter|
      circuit = create_ansatz_circuit(@parameters)
      energy = compute_expectation_value(circuit, @hamiltonian)
      
      if energy < best_energy
        best_energy = energy
        best_params = @parameters.dup
        puts "Iteration #{iter + 1}: New minimum energy = #{energy.round(6)}"
      end
      
      # Update parameters using gradient descent
      update_parameters_gradient_descent(energy)
      
      # Print progress every 20 iterations
      if (iter + 1) % 20 == 0
        puts "Iteration #{iter + 1}: Current energy = #{energy.round(6)}"
      end
    end
    
    @best_energy = best_energy
    @best_params = best_params
    
    puts "=== VQE Optimization Complete ==="
    puts "Final ground state energy: #{best_energy.round(6)}"
    
    { 
      ground_state_energy: best_energy, 
      optimal_parameters: best_params,
      final_circuit: create_ansatz_circuit(best_params)
    }
  end
  
  def create_ansatz_circuit(params)
    circuit = QuantumCircuit.new(@n_qubits)
    
    # Couche de rotation Y paramétrée
    @n_qubits.times do |i|
      ry_gate = QuantumGate.new(QuantumGates.ry_gate(params[i]))
      circuit.add_gate(ry_gate, [i])
    end
    
    # Couche d'intrication
    (@n_qubits - 1).times do |i|
      circuit.add_gate(QuantumGate.cnot, [i, i + 1])
    end
    
    # Seconde couche de rotation
    @n_qubits.times do |i|
      rz_gate = QuantumGate.new(QuantumGates.rz_gate(params[@n_qubits + i]))
      circuit.add_gate(rz_gate, [i])
    end
    
    circuit
  end
  
  def compute_expectation_value(circuit, hamiltonian)
    state = circuit.execute
    
    # Calcul de ⟨ψ|H|ψ⟩
    hamiltonian_state = hamiltonian * state
    expectation = state.inner_product(hamiltonian_state)
    
    # Return real part (should be real for Hermitian operators)
    expectation.respond_to?(:real) ? expectation.real : expectation
  end
  
  def update_parameters_gradient_descent(current_energy)
    learning_rate = 0.01
    epsilon = 0.01  # Small parameter shift for numerical gradient
    
    @parameters.each_with_index do |param, i|
      gradient = compute_parameter_shift_gradient(i, epsilon)
      @parameters[i] = param - learning_rate * gradient
      
      # Keep parameters in valid range [0, 2π]
      @parameters[i] = @parameters[i] % (2 * Math::PI)
    end
  end
  
  def compute_parameter_shift_gradient(param_index, epsilon = 0.01)
    # Parameter shift rule for gradient computation
    shift = Math::PI / 2
    
    # Forward shift
    @parameters[param_index] += shift
    circuit_plus = create_ansatz_circuit(@parameters)
    energy_plus = compute_expectation_value(circuit_plus, @hamiltonian)
    
    # Backward shift
    @parameters[param_index] -= 2 * shift
    circuit_minus = create_ansatz_circuit(@parameters)
    energy_minus = compute_expectation_value(circuit_minus, @hamiltonian)
    
    # Restore original parameter
    @parameters[param_index] += shift
    
    # Gradient using parameter shift rule
    (energy_plus - energy_minus) / 2.0
  end
  
  # Utility methods for creating common Hamiltonians
  def self.create_pauli_z_hamiltonian(n_qubits)
    # Simple Hamiltonian: sum of Z operators
    size = 2**n_qubits
    hamiltonian = Matrix.zero(size)
    
    (0...size).each do |i|
      # Count number of 1s in binary representation
      ones_count = i.to_s(2).count('1')
      # Energy is +1 for each |1⟩ state, -1 for each |0⟩ state
      energy = 2 * ones_count - n_qubits
      hamiltonian[i, i] = energy
    end
    
    hamiltonian
  end
  
  def self.create_ising_hamiltonian(n_qubits, coupling_strength: 1.0)
    # 1D Ising model Hamiltonian
    size = 2**n_qubits
    hamiltonian = Matrix.zero(size)
    
    (0...size).each do |i|
      energy = 0
      
      # Interaction terms between adjacent qubits
      (0...(n_qubits - 1)).each do |j|
        bit_j = (i >> j) & 1
        bit_j_plus_1 = (i >> (j + 1)) & 1
        
        # Convert 0,1 to -1,+1 spins
        spin_j = 2 * bit_j - 1
        spin_j_plus_1 = 2 * bit_j_plus_1 - 1
        
        energy -= coupling_strength * spin_j * spin_j_plus_1
      end
      
      hamiltonian[i, i] = energy
    end
    
    hamiltonian
  end
  
  def self.demonstrate
    puts "=== VQE Algorithm Demonstration ==="
    
    # Test with simple 2-qubit Pauli-Z Hamiltonian
    n_qubits = 2
    hamiltonian = create_pauli_z_hamiltonian(n_qubits)
    
    puts "\nTesting with 2-qubit Pauli-Z Hamiltonian:"
    puts "Hamiltonian matrix:"
    puts hamiltonian.to_a.map { |row| row.map { |x| x.round(2) } }
    
    vqe = VQEAlgorithm.new(hamiltonian, n_qubits)
    result = vqe.optimize_ground_state(iterations: 50)
    
    puts "\nResults:"
    puts "Ground state energy: #{result[:ground_state_energy].round(6)}"
    puts "Optimal parameters: #{result[:optimal_parameters].map { |p| p.round(3) }}"
    
    # Test with Ising model
    puts "\n" + "="*50
    puts "Testing with 2-qubit Ising Hamiltonian:"
    
    ising_hamiltonian = create_ising_hamiltonian(n_qubits, coupling_strength: 0.5)
    puts "Ising Hamiltonian matrix:"
    puts ising_hamiltonian.to_a.map { |row| row.map { |x| x.round(2) } }
    
    vqe_ising = VQEAlgorithm.new(ising_hamiltonian, n_qubits)
    ising_result = vqe_ising.optimize_ground_state(iterations: 50)
    
    puts "\nIsing Model Results:"
    puts "Ground state energy: #{ising_result[:ground_state_energy].round(6)}"
    puts "Optimal parameters: #{ising_result[:optimal_parameters].map { |p| p.round(3) }}"
    
    # Compare with classical exact diagonalization
    puts "\n" + "="*50
    puts "Classical verification (exact diagonalization):"
    
    eigenvalues = ising_hamiltonian.eigenvalues.sort
    puts "Exact ground state energy: #{eigenvalues.first.round(6)}"
    puts "VQE approximation error: #{(ising_result[:ground_state_energy] - eigenvalues.first).abs.round(6)}"
  end
  
  # Method to analyze the convergence behavior
  def analyze_convergence(iterations: 100, tolerance: 1e-6)
    energies = []
    convergence_iteration = nil
    
    iterations.times do |iter|
      circuit = create_ansatz_circuit(@parameters)
      energy = compute_expectation_value(circuit, @hamiltonian)
      energies << energy
      
      # Check for convergence
      if iter > 10 && (energies[-10..-1].max - energies[-10..-1].min).abs < tolerance
        convergence_iteration = iter if convergence_iteration.nil?
      end
      
      update_parameters_gradient_descent(energy)
    end
    
    {
      energy_history: energies,
      converged_at: convergence_iteration,
      final_energy: energies.last,
      convergence_achieved: !convergence_iteration.nil?
    }
  end
end