require_relative '../quantum_circuit'
require_relative '../quantum_gate'
require_relative '../quantum_gates'

class QAOAAlgorithm
  attr_reader :cost_hamiltonian, :n_qubits, :layers, :beta_params, :gamma_params
  
  def initialize(cost_hamiltonian, n_qubits, layers: 3)
    @cost_hamiltonian = cost_hamiltonian
    @n_qubits = n_qubits
    @layers = layers
    @beta_params = Array.new(layers) { rand * Math::PI }
    @gamma_params = Array.new(layers) { rand * 2 * Math::PI }
    @best_cost = Float::INFINITY
    @best_solution = nil
  end
  
  def solve_optimization_problem(iterations: 200)
    best_cost = Float::INFINITY
    best_solution = nil
    best_beta = nil
    best_gamma = nil
    
    puts "=== QAOA Optimization Started ==="
    puts "Layers: #{@layers}, Qubits: #{@n_qubits}"
    puts "Initial β parameters: #{@beta_params.map { |p| p.round(3) }}"
    puts "Initial γ parameters: #{@gamma_params.map { |p| p.round(3) }}"
    
    iterations.times do |iter|
      circuit = create_qaoa_circuit(@beta_params, @gamma_params)
      cost = evaluate_cost_function(circuit)
      solution = extract_solution(circuit)
      
      if cost < best_cost
        best_cost = cost
        best_solution = solution
        best_beta = @beta_params.dup
        best_gamma = @gamma_params.dup
        puts "Iteration #{iter + 1}: New best cost = #{cost.round(6)}"
      end
      
      # Update parameters
      optimize_parameters_cobyla(cost)
      
      # Print progress every 40 iterations
      if (iter + 1) % 40 == 0
        puts "Iteration #{iter + 1}: Current cost = #{cost.round(6)}"
      end
    end
    
    @best_cost = best_cost
    @best_solution = best_solution
    
    puts "=== QAOA Optimization Complete ==="
    puts "Best cost found: #{best_cost.round(6)}"
    puts "Best solution: #{best_solution}"
    
    { 
      optimal_cost: best_cost, 
      solution: best_solution,
      optimal_beta: best_beta,
      optimal_gamma: best_gamma,
      final_circuit: create_qaoa_circuit(best_beta, best_gamma)
    }
  end
  
  def create_qaoa_circuit(beta, gamma)
    circuit = QuantumCircuit.new(@n_qubits)
    
    # État initial de superposition
    @n_qubits.times do |i|
      circuit.add_gate(QuantumGate.new(QuantumGates::H_GATE), [i])
    end
    
    # Couches QAOA alternées
    @layers.times do |layer|
      # Opérateur de coût
      apply_cost_operator(circuit, gamma[layer])
      
      # Opérateur de mélange
      apply_mixer_operator(circuit, beta[layer])
    end
    
    circuit
  end
  
  def apply_cost_operator(circuit, gamma)
    # Implémentation pour MaxCut : RZ sur les arêtes
    (@n_qubits - 1).times do |i|
      circuit.add_gate(QuantumGate.cnot, [i, i + 1])
      
      rz_gate = QuantumGate.new(QuantumGates.rz_gate(2 * gamma))
      circuit.add_gate(rz_gate, [i + 1])
      
      circuit.add_gate(QuantumGate.cnot, [i, i + 1])
    end
    
    # Add cycle closure for ring topology (optional)
    if @n_qubits > 2
      circuit.add_gate(QuantumGate.cnot, [@n_qubits - 1, 0])
      
      rz_gate = QuantumGate.new(QuantumGates.rz_gate(2 * gamma))
      circuit.add_gate(rz_gate, [0])
      
      circuit.add_gate(QuantumGate.cnot, [@n_qubits - 1, 0])
    end
  end
  
  def apply_mixer_operator(circuit, beta)
    # Opérateur de mélange standard : RX sur tous les qubits
    @n_qubits.times do |i|
      rx_gate = QuantumGate.new(QuantumGates.rx_gate(2 * beta))
      circuit.add_gate(rx_gate, [i])
    end
  end
  
  def evaluate_cost_function(circuit)
    measurements = []
    shots = 1000
    
    shots.times do
      c = circuit.copy
      measurements << c.measure_all
    end
    
    # Calcul du coût pour MaxCut
    total_cost = 0
    measurements.each do |measurement|
      cost = calculate_maxcut_cost(measurement)
      total_cost += cost
    end
    
    -total_cost.to_f / measurements.length  # Negative because we want to maximize cuts
  end
  
  def calculate_maxcut_cost(bitstring)
    cost = 0
    
    # Count edges that are cut (adjacent bits are different)
    (@n_qubits - 1).times do |i|
      cost += (bitstring[i] ^ bitstring[i + 1])
    end
    
    # Add cycle closure edge if needed
    if @n_qubits > 2
      cost += (bitstring[@n_qubits - 1] ^ bitstring[0])
    end
    
    cost
  end
  
  def extract_solution(circuit)
    measurements = []
    shots = 1000
    
    shots.times do
      c = circuit.copy
      measurements << c.measure_all
    end
    
    # Find most frequent measurement
    frequency = measurements.group_by(&:itself).transform_values(&:count)
    most_frequent = frequency.max_by { |k, v| v }[0]
    
    most_frequent
  end
  
  def optimize_parameters_cobyla(current_cost)
    # Optimisation par descente de gradient simplifiée
    learning_rate = 0.02
    epsilon = 0.01
    
    # Update beta parameters
    @beta_params.each_with_index do |param, i|
      gradient = compute_beta_gradient(i, epsilon)
      new_param = param - learning_rate * gradient
      @beta_params[i] = [[new_param, 0].max, Math::PI].min
    end
    
    # Update gamma parameters
    @gamma_params.each_with_index do |param, i|
      gradient = compute_gamma_gradient(i, epsilon)
      new_param = param - learning_rate * gradient
      @gamma_params[i] = new_param % (2 * Math::PI)
    end
  end
  
  def compute_beta_gradient(param_index, epsilon)
    # Numerical gradient for beta parameter
    original_value = @beta_params[param_index]
    
    # Forward difference
    @beta_params[param_index] = original_value + epsilon
    circuit_plus = create_qaoa_circuit(@beta_params, @gamma_params)
    cost_plus = evaluate_cost_function(circuit_plus)
    
    # Backward difference
    @beta_params[param_index] = original_value - epsilon
    circuit_minus = create_qaoa_circuit(@beta_params, @gamma_params)
    cost_minus = evaluate_cost_function(circuit_minus)
    
    # Restore original value
    @beta_params[param_index] = original_value
    
    (cost_plus - cost_minus) / (2 * epsilon)
  end
  
  def compute_gamma_gradient(param_index, epsilon)
    # Numerical gradient for gamma parameter
    original_value = @gamma_params[param_index]
    
    # Forward difference
    @gamma_params[param_index] = original_value + epsilon
    circuit_plus = create_qaoa_circuit(@beta_params, @gamma_params)
    cost_plus = evaluate_cost_function(circuit_plus)
    
    # Backward difference
    @gamma_params[param_index] = original_value - epsilon
    circuit_minus = create_qaoa_circuit(@beta_params, @gamma_params)
    cost_minus = evaluate_cost_function(circuit_minus)
    
    # Restore original value
    @gamma_params[param_index] = original_value
    
    (cost_plus - cost_minus) / (2 * epsilon)
  end
  
  # Class methods for different problem types
  def self.create_maxcut_problem(n_qubits, edges = nil)
    # Create adjacency matrix for MaxCut problem
    # Default: create a cycle graph
    edges ||= (0...(n_qubits - 1)).map { |i| [i, i + 1] }
    edges << [n_qubits - 1, 0] if n_qubits > 2  # Close the cycle
    
    adjacency_matrix = Array.new(n_qubits) { Array.new(n_qubits, 0) }
    edges.each do |i, j|
      adjacency_matrix[i][j] = 1
      adjacency_matrix[j][i] = 1
    end
    
    adjacency_matrix
  end
  
  def self.classical_maxcut_solution(adjacency_matrix)
    # Brute force classical solution for small problems
    n = adjacency_matrix.length
    best_cut = 0
    best_partition = nil
    
    (0...(2**n)).each do |partition|
      cut_value = 0
      
      (0...n).each do |i|
        (i + 1...n).each do |j|
          if adjacency_matrix[i][j] == 1
            bit_i = (partition >> i) & 1
            bit_j = (partition >> j) & 1
            cut_value += (bit_i ^ bit_j)
          end
        end
      end
      
      if cut_value > best_cut
        best_cut = cut_value
        best_partition = partition.to_s(2).rjust(n, '0').chars.map(&:to_i)
      end
    end
    
    { cut_value: best_cut, partition: best_partition }
  end
  
  def self.demonstrate
    puts "=== QAOA Algorithm Demonstration ==="
    
    # Test with 4-qubit MaxCut problem
    n_qubits = 4
    edges = [[0, 1], [1, 2], [2, 3], [3, 0], [0, 2]]  # Square with diagonal
    adjacency_matrix = create_maxcut_problem(n_qubits, edges)
    
    puts "\nTesting 4-qubit MaxCut problem:"
    puts "Edges: #{edges}"
    puts "Adjacency matrix:"
    adjacency_matrix.each { |row| puts row.inspect }
    
    # Classical solution for comparison
    classical_result = classical_maxcut_solution(adjacency_matrix)
    puts "\nClassical optimal solution:"
    puts "Max cut value: #{classical_result[:cut_value]}"
    puts "Optimal partition: #{classical_result[:partition]}"
    
    # QAOA solution
    puts "\n" + "="*50
    puts "QAOA Solution:"
    
    # Create dummy cost Hamiltonian (simplified for demonstration)
    cost_hamiltonian = Matrix.identity(2**n_qubits)
    
    qaoa = QAOAAlgorithm.new(cost_hamiltonian, n_qubits, layers: 2)
    result = qaoa.solve_optimization_problem(iterations: 100)
    
    puts "\nQAOA Results:"
    puts "Best cost: #{result[:optimal_cost].round(6)}"
    puts "Best solution: #{result[:solution]}"
    puts "Optimal β: #{result[:optimal_beta].map { |x| x.round(3) }}"
    puts "Optimal γ: #{result[:optimal_gamma].map { |x| x.round(3) }}"
    
    # Calculate actual cut value for QAOA solution
    qaoa_cut_value = qaoa.calculate_maxcut_cost(result[:solution])
    puts "QAOA cut value: #{qaoa_cut_value}"
    puts "Approximation ratio: #{qaoa_cut_value.to_f / classical_result[:cut_value]}"
    
    # Test with different layer depths
    puts "\n" + "="*50
    puts "Layer depth analysis:"
    
    [1, 2, 3, 4].each do |layers|
      qaoa_test = QAOAAlgorithm.new(cost_hamiltonian, n_qubits, layers: layers)
      test_result = qaoa_test.solve_optimization_problem(iterations: 50)
      test_cut = qaoa_test.calculate_maxcut_cost(test_result[:solution])
      
      puts "#{layers} layers: cut = #{test_cut}, ratio = #{(test_cut.to_f / classical_result[:cut_value]).round(3)}"
    end
  end
  
  # Performance analysis method
  def analyze_performance(classical_optimum, iterations: 100)
    costs = []
    approximation_ratios = []
    
    iterations.times do |iter|
      circuit = create_qaoa_circuit(@beta_params, @gamma_params)
      cost = -evaluate_cost_function(circuit)  # Convert back to positive
      costs << cost
      approximation_ratios << cost / classical_optimum
      
      optimize_parameters_cobyla(-cost)  # Pass negative cost for minimization
    end
    
    {
      cost_history: costs,
      ratio_history: approximation_ratios,
      final_ratio: approximation_ratios.last,
      best_ratio: approximation_ratios.max
    }
  end
end