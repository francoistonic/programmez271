require 'matrix'

class Qubit
  attr_reader :state
  
  def initialize(alpha = 1, beta = 0)
    # Normalisation pour respecter |α|² + |β|² = 1
    norm = Math.sqrt(alpha.abs2 + beta.abs2)
    @state = Vector[Complex(alpha) / norm, Complex(beta) / norm]
  end
  
  def measure
    # Probabilité d'obtenir |0⟩
    prob_zero = @state[0].abs2
    
    if rand < prob_zero
      @state = Vector[1, 0]
      0
    else
      @state = Vector[0, 1]
      1
    end
  end
  
  def probabilities
    [@state[0].abs2, @state[1].abs2]
  end
  
  def copy
    Qubit.new(@state[0], @state[1])
  end
  
  def state=(new_state)
    @state = new_state
  end
end