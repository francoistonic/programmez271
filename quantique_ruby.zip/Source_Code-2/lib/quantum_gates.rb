require 'matrix'

module QuantumGates
  # Porte de Pauli-X (équivalent quantique de NOT)
  X_GATE = Matrix[
    [0, 1],
    [1, 0]
  ]
  
  # Porte de Hadamard (crée la superposition)
  H_GATE = Matrix[
    [1/Math.sqrt(2), 1/Math.sqrt(2)],
    [1/Math.sqrt(2), -1/Math.sqrt(2)]
  ]
  
  # Porte de Pauli-Y
  Y_GATE = Matrix[
    [0, -Complex(0, 1)],
    [Complex(0, 1), 0]
  ]
  
  # Porte de Pauli-Z
  Z_GATE = Matrix[
    [1, 0],
    [0, -1]
  ]
  
  # Porte de phase
  S_GATE = Matrix[
    [1, 0],
    [0, Complex(0, 1)]
  ]
  
  # Porte T (π/8)
  T_GATE = Matrix[
    [1, 0],
    [0, Complex(Math.cos(Math::PI/4), Math.sin(Math::PI/4))]
  ]
  
  # Identity gate
  I_GATE = Matrix[
    [1, 0],
    [0, 1]
  ]
  
  # Rotation gates
  def self.rx_gate(theta)
    Matrix[
      [Math.cos(theta/2), -Complex(0, Math.sin(theta/2))],
      [-Complex(0, Math.sin(theta/2)), Math.cos(theta/2)]
    ]
  end
  
  def self.ry_gate(theta)
    Matrix[
      [Math.cos(theta/2), -Math.sin(theta/2)],
      [Math.sin(theta/2), Math.cos(theta/2)]
    ]
  end
  
  def self.rz_gate(theta)
    Matrix[
      [Complex(Math.cos(theta/2), -Math.sin(theta/2)), 0],
      [0, Complex(Math.cos(theta/2), Math.sin(theta/2))]
    ]
  end
end