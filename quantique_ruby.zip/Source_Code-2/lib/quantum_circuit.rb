require 'matrix'
require_relative 'quantum_gate'
require_relative 'quantum_gates'

class QuantumCircuit
  attr_reader :num_qubits, :gates
  
  def initialize(num_qubits)
    @num_qubits = num_qubits
    @gates = []
    # État initial : tous les qubits à |0⟩
    @state = create_initial_state
  end
  
  def add_gate(gate, target_qubits)
    @gates << { gate: gate, targets: Array(target_qubits) }
    self
  end
  
  def execute
    @gates.each do |gate_info|
      apply_gate(gate_info[:gate], gate_info[:targets])
    end
    @state
  end
  
  def measure_all
    probabilities = calculate_probabilities
    
    # Échantillonnage selon les probabilités
    outcome = weighted_random_choice(probabilities)
    
    # Conversion de l'indice en chaîne binaire
    outcome.to_s(2).rjust(@num_qubits, '0').chars.map(&:to_i)
  end
  
  def copy
    new_circuit = QuantumCircuit.new(@num_qubits)
    new_circuit.instance_variable_set(:@state, @state.clone)
    new_circuit.instance_variable_set(:@gates, @gates.clone)
    new_circuit
  end
  
  def to_qasm
    # Export to OpenQASM format
    qasm = "OPENQASM 2.0;\n"
    qasm += "include \"qelib1.inc\";\n"
    qasm += "qreg q[#{@num_qubits}];\n"
    qasm += "creg c[#{@num_qubits}];\n"
    
    @gates.each do |gate_info|
      gate = gate_info[:gate]
      targets = gate_info[:targets]
      
      # Add gate operations
      if gate.num_qubits == 1
        qasm += "h q[#{targets[0]}];\n" if gate.matrix == QuantumGates::H_GATE
        qasm += "x q[#{targets[0]}];\n" if gate.matrix == QuantumGates::X_GATE
        qasm += "y q[#{targets[0]}];\n" if gate.matrix == QuantumGates::Y_GATE
        qasm += "z q[#{targets[0]}];\n" if gate.matrix == QuantumGates::Z_GATE
      elsif gate.num_qubits == 2
        qasm += "cx q[#{targets[0]}],q[#{targets[1]}];\n"
      end
    end
    
    # Add measurements
    @num_qubits.times do |i|
      qasm += "measure q[#{i}] -> c[#{i}];\n"
    end
    
    qasm
  end
  
  private
  
  def create_initial_state
    # Vecteur d'état pour n qubits (2^n dimensions)
    size = 2**@num_qubits
    state_array = Array.new(size, 0)
    state_array[0] = Complex(1, 0)  # |00...0⟩
    Vector[*state_array]
  end
  
  def apply_gate(gate, target_qubits)
    if gate.num_qubits == 1
      apply_single_qubit_gate(gate, target_qubits[0])
    elsif gate.num_qubits == 2
      apply_two_qubit_gate(gate, target_qubits[0], target_qubits[1])
    else
      raise "Gates with more than 2 qubits not yet supported"
    end
  end
  
  def apply_single_qubit_gate(gate, target)
    new_state_array = Array.new(2**@num_qubits, 0)
    
    (0...2**@num_qubits).each do |i|
      # Extract the bit value at the target position
      target_bit = (i >> (@num_qubits - 1 - target)) & 1
      
      # Apply the gate matrix
      if target_bit == 0
        # |0⟩ component
        j0 = i
        j1 = i | (1 << (@num_qubits - 1 - target))
        
        new_state_array[j0] += gate.matrix[0, 0] * @state[i]
        new_state_array[j1] += gate.matrix[1, 0] * @state[i]
      else
        # |1⟩ component
        j0 = i & ~(1 << (@num_qubits - 1 - target))
        j1 = i
        
        new_state_array[j0] += gate.matrix[0, 1] * @state[i]
        new_state_array[j1] += gate.matrix[1, 1] * @state[i]
      end
    end
    
    @state = Vector[*new_state_array]
  end
  
  def apply_two_qubit_gate(gate, control, target)
    new_state_array = Array.new(2**@num_qubits, 0)
    
    (0...2**@num_qubits).each do |i|
      control_bit = (i >> (@num_qubits - 1 - control)) & 1
      target_bit = (i >> (@num_qubits - 1 - target)) & 1
      
      input_state = control_bit * 2 + target_bit
      
      # Apply gate matrix
      4.times do |output_state|
        output_control = (output_state >> 1) & 1
        output_target = output_state & 1
        
        # Calculate the new index
        new_i = i
        new_i = set_bit(new_i, @num_qubits - 1 - control, output_control)
        new_i = set_bit(new_i, @num_qubits - 1 - target, output_target)
        
        new_state_array[new_i] += gate.matrix[output_state, input_state] * @state[i]
      end
    end
    
    @state = Vector[*new_state_array]
  end
  
  def set_bit(number, position, value)
    if value == 1
      number | (1 << position)
    else
      number & ~(1 << position)
    end
  end
  
  def calculate_probabilities
    @state.map { |amplitude| amplitude.abs2 }
  end
  
  def weighted_random_choice(weights)
    r = rand
    cumulative = 0
    weights.each_with_index do |weight, index|
      cumulative += weight
      return index if r <= cumulative
    end
    weights.length - 1
  end
end