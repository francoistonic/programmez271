/*---------------------------------------------------------------------------------


    Utilisaiton de Tiled pour afficher une carte sur SNES
    -- Alekmaul


---------------------------------------------------------------------------------*/
#include <snes.h>

//---------------------------------------------------------------------------------
extern char tileset, tilesetend, tilesetpal;
extern char tilesetdef, tilesetatt;             // pour la carte & tileset

extern char mapkeen, objmap;

extern void heroinit(u16 xp, u16 yp, u16 type, u16 minx, u16 maxx);
extern void heroupdate(u8 idx);
extern void monsterinit(u16 xp, u16 yp, u16 type, u16 minx, u16 maxx);
extern void monsterupdate(u8 idx);

//---------------------------------------------------------------------------------
u16 pad0;                                       // gestion du pad

//---------------------------------------------------------------------------------
int main(void)
{
    // Initialise le layer avec les tiles et met aussi à jour la taille de la carte (0x6800 est obligatoire pour le moteur de carte)
    bgInitTileSet(0, &tileset, &tilesetpal, 0, (&tilesetend - &tileset), 16 * 2, BG_16COLORS, 0x2000);
    bgSetMapPtr(0, 0x6800, SC_64x32);

    // Initialise le moteur de sprites (0x0000 pour les sprites "large", 0x1000 pour les sprites "small")
    oamInitDynamicSprite(0x0000, 0x1000, 0, 0, OBJ_SIZE8_L16);

    // Active le moteur d'objet
    objInitEngine();

    // Intialise les fonctions de gestion des objets (pas de refresh car fait dans l'update)
    objInitFunctions(0, &heroinit, &heroupdate, NULL);
    objInitFunctions(1, &monsterinit, &monsterupdate, NULL);

    // Charge tous les objets en memoire
    objLoadObjects((char *)&objmap);

    // Charge la carte en memoire, met a jour les attributs des tuiles aussi 
    mapLoad((u8 *)&mapkeen, (u8 *)&tilesetdef, (u8 *)&tilesetatt);

    // Pas de BG2, ni de BG3, en mode 16 couleurs
    setMode(BG_MODE1, 0);
    bgSetDisable(1); bgSetDisable(2);

    // Active l'affichage
    setScreenOn();

    // Attend la VBL et met a jour les sprites ;-) )
    WaitForVBlank();

    // Attend a l'infini :P
    while (1)
    {
        // Met  jour la carte en fonciton de la camera
        pad0 = padsCurrent(0);
        mapUpdate();

        // Met a jour tous les objets disponibles
        objUpdateAll();

        // Prepare prochaine frame et attend la VBlank
        oamInitDynamicSpriteEndFrame();
        WaitForVBlank();
        mapVblank();
        oamVramQueueUpdate();
    }
    return 0;
}
