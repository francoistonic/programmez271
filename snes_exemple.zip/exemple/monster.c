/*---------------------------------------------------------------------------------


    Utilisation de Tiled pour afficher une carte sur SNES
    Module "gestion du monster"
    -- Alekmaul


---------------------------------------------------------------------------------*/
#include <snes.h>

#define MONSTER_LEFT 1
#define MONSTER_RIGHT 2
#define MONSTER_XVELOC 0x028A

extern char gfxmonster, palmonster;

//---------------------------------------------------------------------------------
t_objs *monsterobj;                 // pointeur vers l'objet monstre
s16 *monsterox,*monsteroy;          // coordonnees x/y basiques avec des types "fixed point"
u16 monsterx;                       // coordonnees x & y du monstre sur la carte (pas seulement l'ecran)
u16 monsternum;                     // pour avoir le numero correct du sprite
//---------------------------------------------------------------------------------
// Init function for monster object
void monsterinit(u16 xp, u16 yp, u16 type, u16 minx, u16 maxx)
{
    // prepare new object
    if (objNew(type, xp, yp) == 0)
        // no more space, get out
        return;

    // Init some vars for snes sprite (objgetid is the current object id)
    objGetPointer(objgetid);
    monsterobj = &objbuffers[objptr - 1];

    monsterobj->width = 16; monsterobj->height = 16;
    monsterobj->xmin = minx;
    monsterobj->xmax = maxx;
    monsterobj->count = 10;
    monsterobj->sprnum = 2;  // IMPORTANT ! A gerer avec une variable suivant le nombre d'objet à l'ecran (2 pour le heros, on est donc à 2 ici)
    monsterobj->sprframe=0;
    monsterobj->dir = MONSTER_LEFT;
    monsterobj->xvel = -MONSTER_XVELOC;

    // les variables des coordonnees
    monsterox = (u16 *)&(monsterobj->xpos + 1);
    monsteroy = (u16 *)&(monsterobj->ypos + 1);

    // prepare dynamic sprite object
    oambuffer[monsterobj->sprnum].oamframeid = 0;
    oambuffer[monsterobj->sprnum].oamrefresh = 1;
    oambuffer[monsterobj->sprnum].oamattribute = 0x20 | (1 << 1); // palette 1 of sprite and sprite 16x16 and priority 2
    oambuffer[monsterobj->sprnum].oamgraphics = &gfxmonster;

    // Init Sprites palette
    setPalette(&palmonster, 128 + 1 * 16, 16 * 2);
}

//---------------------------------------------------------------------------------
// Update function for monster object
void monsterupdate(u8 idx)
{
    // recupere l'objet a mettre a jour
    monsterobj = &objbuffers[idx];
    monsterox = (u16 *)&(monsterobj->xpos + 1);
    monsteroy = (u16 *)&(monsterobj->ypos + 1);
    monsternum=monsterobj->sprnum;
    monsterx = *monsterox;

    monsterobj->count++;
    if (monsterobj->count >= 3) { // Met a jour 20 fois par seconde
        monsterobj->count = 0;
        monsterobj->sprframe = (1 - monsterobj->sprframe); // plus rapide car que 2 frames
		oambuffer[monsternum].oamframeid=monsterobj->sprframe; 
		oambuffer[monsternum].oamrefresh = 1;

        // si on va a gauche
        if (monsterobj->dir == MONSTER_LEFT) {
            if (monsterx <= monsterobj->xmin) {
                monsterobj->dir = MONSTER_RIGHT;
                monsterobj->xvel = +MONSTER_XVELOC;
                monsterobj->yvel = 0;
				oambuffer[monsternum].oamattribute &=~0x40;
            }
            else {
                monsterobj->xvel = -MONSTER_XVELOC;
            }
        }
        // donc, on va a droite :)
        else {
            if (monsterx >= monsterobj->xmax) {
                monsterobj->dir = MONSTER_LEFT;
                monsterobj->xvel = -MONSTER_XVELOC;
                monsterobj->yvel = 0;
				oambuffer[monsternum].oamattribute |=0x40;
            }
            else {
                monsterobj->xvel = +MONSTER_XVELOC;
            }
        }
        // met a jour les coordonnees
        objUpdateXY(idx);
    }

    

    // met a jour le psrite a l'ecran
    oambuffer[monsternum].oamx = monsterx - x_pos;
    oambuffer[monsternum].oamy =(*monsteroy) - y_pos;
    oamDynamic16Draw(monsternum);
}
