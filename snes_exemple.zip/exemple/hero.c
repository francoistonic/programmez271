/*---------------------------------------------------------------------------------


    Utilisation de Tiled pour afficher une carte sur SNES
    Module "gestion du hero"
    -- Alekmaul


---------------------------------------------------------------------------------*/
#include <snes.h>

//---------------------------------------------------------------------------------
#define GRAVITY 48
#define JUMPVALUE (GRAVITY * 30)

#define HERO_MAXACCEL 0x0140
#define HERO_ACCEL 0x0038
#define HERO_JUMPING 0x0394
#define HERO_HIJUMPING 0x0594

enum
{
    HERODOWN = 0,
    HEROJUMPING = 1,
    HEROWALK = 2,
    HEROSTAND = 6
}; // Etat du heros

extern char gfxhero, palhero;

extern u16 pad0;                                       // gestion du pad

//---------------------------------------------------------------------------------
t_objs *heroobj;            // pointeur vers l'objet heros
s16 *heroox, *herooy;       // coordonnees x/y basiques avec des types "fixed point"
s16 *heroxv, *heroyv;       // velocite x/y basiques avec des types "fixed point"
u16 herox, heroy;           // coordonnees x & y du heros sur la carte (pas seulement l'ecran)
u8 herofidx, flip;          // Pour gerer l'affichage du heros

//---------------------------------------------------------------------------------
// Fonciton d'init pour l'objet Hero
void heroinit(u16 xp, u16 yp, u16 type, u16 minx, u16 maxx)
{
    // Prepare le nouvel objet
    if (objNew(type, xp, yp) == 0)
        // plus de place, on sort (ne doit pas arriver)
        return;

    // Init. de variables pour le sprite (objgetid est l'id de l'objet courant)
    //  comme la taille du sprite (de 16x24 avec un offset en Y de 8, cf le graphique du sprite)
    objGetPointer(objgetid);
    heroobj = &objbuffers[objptr - 1];
    heroobj->width = 16; heroobj->height = 24; heroobj->yofs=8;
	
    // Recupert les corrdonnées et la velocite
    heroox = (u16 *)&(heroobj->xpos + 1);
    herooy = (u16 *)&(heroobj->ypos + 1);
    heroxv = (short *)&(heroobj->xvel);
    heroyv = (short *)&(heroobj->yvel);

    // Variable de gestion interne de l'objet
    herofidx = 0;
    heroobj->action = ACT_STAND;

    // prepare le sprite (2 sprites de 16x16)
    oambuffer[0].oamframeid = 0;
    oambuffer[0].oamrefresh = 1;
    oambuffer[0].oamattribute = 0x20 | (0 << 1); // palette 0 des sprites and sprite 16x16 and priorite 2 
    oambuffer[0].oamgraphics = &gfxhero;
    oambuffer[1].oamframeid = 1;
    oambuffer[1].oamrefresh = 1;
    oambuffer[1].oamattribute = 0x20 | (0 << 1); // palette 0 des sprites and sprite 16x16 and priorite 2 
    oambuffer[1].oamgraphics = &gfxhero;

    // Init palette du sprites 
    setPalette(&palhero, 128 + 0 * 16, 16 * 2);
}

//---------------------------------------------------------------------------------
// Gestion du deplacement du hero
void herowalk(u8 idx)
{
    // update animation
    flip++;
    if ((flip & 3) == 3)
    {
        herofidx+=2;
        if (herofidx>6) herofidx = 0;
        oambuffer[0].oamframeid = herofidx;
        oambuffer[0].oamrefresh = 1;
        oambuffer[1].oamframeid = herofidx+1;
        oambuffer[1].oamrefresh = 1;
    }

    // check if we are still walking or not with the velocity properties of object
    if (*heroyv != 0)
        heroobj->action = ACT_FALL;
    else if ((*heroxv == 0) && (*heroyv == 0))
        heroobj->action = ACT_STAND;
}

//---------------------------------------------------------------------------------
// Gestion de la chute si plus de sol
void herofall(u8 idx)
{
    // Si on ne chute plus, on reste debout
    if (*heroyv == 0)
    {
        heroobj->action = ACT_STAND;
        oambuffer[0].oamframeid = 0;
        oambuffer[0].oamrefresh = 1;
        oambuffer[1].oamframeid = 1;
        oambuffer[1].oamrefresh = 1;
    }
}

//---------------------------------------------------------------------------------
// hero jump management
void herojump(u8 idx)
{
    // change sprite
    if (oambuffer[0].oamframeid != 8)
    {
        oambuffer[0].oamframeid = 8;
        oambuffer[0].oamrefresh = 1;
        oambuffer[1].oamframeid = 9;
        oambuffer[1].oamrefresh = 1;
    }

    // if no more jumping, then fall
    if (*heroyv >= 0)
        heroobj->action = ACT_FALL;
}

//---------------------------------------------------------------------------------
// Update function for hero object
void heroupdate(u8 idx)
{
    // check only the keys for the game
    if (pad0 & (KEY_RIGHT | KEY_LEFT | KEY_A))
    {
        // go to the left
        if (pad0 & KEY_LEFT)
        {
            // update anim (sprites 2-3)
            oambuffer[0].oamattribute |= 0x40; // flip sprite
            oambuffer[1].oamattribute |= 0x40; // flip sprite

            // update velocity
            heroobj->action = ACT_WALK;
            *heroxv -= (HERO_ACCEL);
            if (*heroxv <= (-HERO_MAXACCEL))
                *heroxv = (-HERO_MAXACCEL);
        }
        // go to the right
        if (pad0 & KEY_RIGHT)
        {
            // update anim (sprites 2-3)
            oambuffer[0].oamattribute &= ~0x40; // ne flip pas le sprite
            oambuffer[1].oamattribute &= ~0x40; // ne flip pas le sprite

            // update velocity
            heroobj->action = ACT_WALK;
            *heroxv += (HERO_ACCEL);
            if (*heroxv >= (HERO_MAXACCEL))
                *heroxv = (HERO_MAXACCEL);
        }
        // jump 
        if (pad0 & KEY_A)
        {
            // we can jump only if we are on ground
            if ((heroobj->tilestand != 0))
            {
                heroobj->action = ACT_JUMP;
                // if key up, jump 2x more
                if (pad0 & KEY_UP)
                    *heroyv = -(HERO_HIJUMPING);
                else
                    *heroyv = -(HERO_JUMPING);
            }
        }
    }

    // 1), check les collisions avec la carte
    objCollidMap(idx);

    //  met a jour l'animation suivant l'etat du heros
    if (heroobj->action == ACT_WALK)
        herowalk(idx);
    else if (heroobj->action == ACT_FALL)
        herofall(idx);
    else if (heroobj->action == ACT_JUMP)
        herojump(idx);

    // met a jour la position sur la carte
    objUpdateXY(idx);

    // quelques limites ;)
    if (*heroox <= 0)
        *heroox = 0;
    if (*herooy <= 0)
        *herooy = 0;

    // change les coordonnées du sprites sur la position sur la carte
    herox = (*heroox);
    heroy = (*herooy);
    oambuffer[0].oamx = herox - x_pos;
    oambuffer[0].oamy = heroy - y_pos;
    oambuffer[1].oamx = herox - x_pos;
    oambuffer[1].oamy = heroy - y_pos+16;
    oamDynamic16Draw(0);
    oamDynamic16Draw(1);

    // Met a jour la camera suivant la position du heros
    mapUpdateCamera(herox, heroy);
}
